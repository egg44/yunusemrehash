<?php
// Base64 decode işlemi
$decodedText = '';
$encodedText = '';
$error = '';

// Base64 çözme işlemi
if (isset($_POST['decode'])) {
    $encodedText = $_POST['encodedText'];
    // Base64 çözme işlemi
    if (!empty($encodedText)) {
        $decodedText = base64_decode($encodedText);
        if ($decodedText === false) {
            $error = 'Geçersiz Base64 kodu!';
        }
    } else {
        $error = 'Lütfen Base64 kodunu girin!';
    }
}

// Base64 encode işlemi
if (isset($_POST['encode'])) {
    $plainText = $_POST['plainText'];
    // Base64 encode işlemi
    if (!empty($plainText)) {
        $encodedText = base64_encode($plainText);
    } else {
        $error = 'Lütfen bir metin girin!';
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Base64 Encode/Decode</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f4f4f9;
            color: #333;
            background-image: url('https://backiee.com/static/wallpapers/1000x563/416986.jpg'); /* Anime Kızı Resmi */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .container {
            width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* İçeriği şeffaf beyaz yapıyoruz */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
        }
        textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            margin: 10px 0;
        }
        .button:hover {
            background-color: #45a049;
        }
        .error {
            color: red;
            text-align: center;
        }
        .result {
            border: 1px solid #ddd;
            padding: 10px;
            background-color: #f9f9f9;
            word-wrap: break-word;
            white-space: pre-wrap;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Base64 Encode / Decode</h2>

    <!-- Base64 Decode Form -->
    <form method="POST">
        <h3>Base64 Decode</h3>
        <textarea name="encodedText" placeholder="Base64 kodlanmış metni buraya yapıştırın..."><?= htmlspecialchars($encodedText) ?></textarea><br>
        <input type="submit" name="decode" value="Decode" class="button">
    </form>

    <?php if ($decodedText): ?>
        <h3>Çözümlenen Metin:</h3>
        <div class="result"><?= htmlspecialchars($decodedText) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <!-- Base64 Encode Form -->
    <form method="POST">
        <h3>Base64 Encode</h3>
        <textarea name="plainText" placeholder="Metninizi buraya yazın..."><?= htmlspecialchars($plainText) ?></textarea><br>
        <input type="submit" name="encode" value="Encode" class="button">
    </form>

    <?php if ($encodedText && !$error): ?>
        <h3>Base64 Kodlanmış Metin:</h3>
        <div class="result"><?= htmlspecialchars($encodedText) ?></div>
    <?php endif; ?>
</div>

</body>
</html>

<?php

function convertNetscapeToJson($netscapeCookies) {
    $cookies = [];

    // Netscape çerezlerini satır satır işleyelim
    $lines = explode("\n", $netscapeCookies);
    
    // Her satırı işleyerek çerezleri JSON formatında diziye ekleyelim
    foreach ($lines as $line) {
        // Yalnızca çerez satırlarını işleyelim (boş satırlar ve başlık satırları hariç)
        if (empty($line) || strpos($line, '#') === 0) {
            continue;
        }

        // Çerez bilgilerini ayıralım
        $parts = preg_split('/\s+/', $line);
        if (count($parts) >= 7) {
            // Fix 'TRUE' issue with path
            if ($parts[2] === 'TRUE') {
                $parts[2] = '/';  // Correcting 'TRUE' to root path '/'
            }

            $cookie = [
                'domain' => $parts[0],
                'path' => $parts[2],
                'secure' => ($parts[3] == 'TRUE'),
                'expiration' => $parts[4] !== '0' ? (int) $parts[4] : null,
                'name' => $parts[5],
                'value' => $parts[6],
            ];

            // Çerezi diziye ekleyelim
            $cookies[] = $cookie;
        }
    }

    // JSON formatına dönüştürelim
    return json_encode($cookies, JSON_PRETTY_PRINT);
}

// Formu işlerken
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['netscapeCookies'])) {
    $netscapeCookies = $_POST['netscapeCookies'];
    $jsonCookies = convertNetscapeToJson($netscapeCookies);
} else {
    $jsonCookies = null;
}

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie Converter</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: url('https://backiee.com/static/wallpapers/1000x563/416986.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #fff;
        }
        textarea {
            width: 100%;
            height: 300px;
            margin: 20px 0;
            padding: 10px;
            border: 1px solid #ccc;
            font-family: monospace;
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
        }
        pre {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 10px;
            border: 1px solid #ccc;
            white-space: pre-wrap;
            word-wrap: break-word;
            color: #ddd;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }
        button:hover {
            background-color: #45a049;
        }
        h1 {
            font-size: 28px;
            text-align: center;
            text-shadow: 2px 2px 5px rgba(0,0,0,0.7);
        }
        label {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Netscape Cookie to JSON Converter</h1>
    <form method="POST">
        <label for="netscapeCookies">Netscape Format Cookies:</label><br>
        <textarea id="netscapeCookies" name="netscapeCookies" placeholder="Netscape format cookies here..."><?php echo isset($netscapeCookies) ? htmlspecialchars($netscapeCookies) : ''; ?></textarea><br>
        <button type="submit">Convert to JSON</button>
    </form>

    <?php if ($jsonCookies): ?>
        <h2>Converted JSON Output:</h2>
        <pre><?php echo $jsonCookies; ?></pre>
    <?php endif; ?>
</body>
</html>
